---
priority: medium
effort: low
depends: []
issue_type: documentation
status: Done
labels: [aitasks, windows]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-16 13:28
updated_at: 2026-02-16 14:24
completed_at: 2026-02-16 14:24
boardidx: 10
---

installing-windows.md doc has several issues 1) don't list a github account as prerequisite 2) Github Authentication is not needed only for issue integration, it is also needed for full aitasks functionality, but rename the section as authentication with your git remote. and there should be subsection for gitlab and bitbucket, with TODO for gitlab and bitbucke. by the way this is not specific to windows, this is for all platformss. 3) terminal options: should not say taht warp is recommended. list warp as the LAST option. also ait board is fully functional in WSL terminal, there is no issue with it. 4) the known issues: keep only the section on legacy console
