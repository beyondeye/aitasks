---
priority: medium
effort: low
depends: []
issue_type: chore
status: Done
labels: [aitask_reviewguide]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 12:00
updated_at: 2026-02-19 12:13
completed_at: 2026-02-19 12:13
---

we have recently imported style_guides for several language in the local reviewguides directory (look at recent commits) I want to copy this imported style guild to the seed reviewguides of the aitasks framework
