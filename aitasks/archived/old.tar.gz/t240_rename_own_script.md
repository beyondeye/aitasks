---
priority: medium
effort: low
depends: []
issue_type: refactor
status: Done
labels: [bash_scripts, aitask_pick]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 08:13
updated_at: 2026-02-25 09:19
completed_at: 2026-02-25 09:19
---

the aitask_own.sh script is specifically designed for work inside aitask_pick skill, it is not a general purpose script so rename it to aitask_pick_own.sh, make sure to rename all references to it in skills
