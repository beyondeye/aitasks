---
priority: medium
effort: low
depends: []
issue_type: documentation
status: Done
labels: [bash_scripts, ait_dispatcher]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 12:46
updated_at: 2026-02-25 13:00
completed_at: 2026-02-25 13:00
---

currently when running ait without argument it shows the possbile commands. command list is long and there is no organization of the command list for better "parsing" (by a user) of the available command categories and operations. this is a small change but it can help
