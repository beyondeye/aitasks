---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [bash_scripts, development]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 19:01
updated_at: 2026-02-22 23:19
completed_at: 2026-02-22 23:19
---

need to add in web site documentation, in the development section that shellcheck is a development dependency (brew install shellcheck on macos) and add also install isntruction for archlinux and ubuntu
