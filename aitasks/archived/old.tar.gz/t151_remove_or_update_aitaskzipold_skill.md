---
priority: medium
effort: low
depends: []
issue_type: refactor
status: Done
labels: [claudeskills]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 13:54
updated_at: 2026-02-17 14:09
completed_at: 2026-02-17 14:09
---

The claude skill aitask-zipold has not been updated after the latest updates to the aitask_zip_old.sh. I am not sure that we actually need this skill any more. we can just run the bash script. so delete this skill (unless you find some reason to keep it: try to convince me). nee also to update the documentation in docs/development.md in the Release Process section to refer the bash script directly instead of the skill
