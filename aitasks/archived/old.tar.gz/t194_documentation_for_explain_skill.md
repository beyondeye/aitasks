---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_explain]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 10:58
updated_at: 2026-02-22 14:36
completed_at: 2026-02-22 14:36
---

add documentaiton in in web site for the explain skill. add both skill reference documentation in docs/skills and also a new workflow: explain with the various use cases of the skill, the fact that thanks to the stored information of the archived aiplans and tasks it has structured information of the evolution of each file in the repo and can help to solve the problem of "cognitive depth" in ai agents based development add reference to (https://margaretstorey.com/blog/2026/02/09/cognitive-debt/), where the aitask-review skill for solving the more classical "technical debt" problem in development
