---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 09:49
updated_at: 2026-02-25 10:20
completed_at: 2026-02-25 10:20
---

currently the documentation for the ait board TUI in website has no images. there are now 4 svg images in the imgs directory (aitasks_board_*.svg) please put them in appropriate place in the documentation. only place each image only once. check that docsy accept them and hugo site build properly. ask for user verification
