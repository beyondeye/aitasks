---
priority: medium
effort: high
depends: []
issue_type: bug
status: Done
labels: [aitakspickrem, remote]
created_at: 2026-02-23 15:33
updated_at: 2026-02-25 00:18
completed_at: 2026-02-25 00:18
boardcol: now
boardidx: 10
---

I am trying to run task t187 on claude web. I started the session with aitask-pickrem 187. steps 1-4 of workflow run without errors. step 5 assign task still has issues:  aitask_own.sh 187 fails with LOCK_ERROR:race_exhaustion. when looking at the aitask-locks branch I don't see any file named after t187. the claude code running the remote tasks finally write the diagnosis that the environment has no push access to aitasks-locks branch (HTTP 403) and the comment: this is expected for claude code web with branch-restricted permissions. so basically we cannot lock aitasks when executing with aitask-pickrem. a possible alternative would be lock them manually before starting claude code web, for example if we create an android/ios board app that replicate features of the ait board app. also we should probably add the feature of allowing locking/unlccking tasks in the aitboard for remote execution. lock should probably expire after a day or so. there was previous work on how to handle stale locks to task file (see task t220) but I am not sure that work there was conclusive. so in brief what should be done 1)in aitask-pickrem remove locking logic and substitute instead with retrieval of the metadata of who is currently locking the task we want to execute: show email and when it was locked so at least we can see if A DIFFERENT USER IS TRYING implement the task 2) In task details in ait board ad button to lock/unlock a task: for force unlocking show the current locking metadata (email of who locked and locking time) 3) verify if task t220 has properly implemented some method to clear stale locks. this is a complex tasks, and it should be split in child tasks

Now that I think again about it there is an additional issue with claude web: it would probably will not have push access to the task-data branch with the plans, so it cannot write task plans, manipulate their status and so. this was also true before
because in any case claude web work in a separate branch. so in any case we need an ad hoc procedure when merging changes made by claude web in a branch to also read the aiplans/aitask modification made by claude web (that must be made in the
branch claude web is working in) and marge both the aitask aiplans (and archive) the updated aiplans aitasks to the task-data branch, and the actual code in the main branch. this is complex and potentially lengthy task task potentially nullify
the usefulness of running an aitask on claude web: I probably need to run a a local claude skill to check for branches with "signs" that it was a branch with claude web developement and handle the merge of code and tasks data. But it can be done.
Technically it can be implemented. so we need a way to identify branches that are results of claude code web runs: need to add some "marking" in the aitask-pickrem when a task is completed, and as said earlier implement all aitask and aiplan 
operations to operation in the current branch, the only one available to claude web

An addiional question if I should make a custom tailored skill aitask-pickrem that works specifically for claude-web or should I have an additional aitask-pickrem for environment with less limitations, that is sandobxed environemnt perhaps
set up by the user with some additional access permissions (for example to the task-data branch and the task-lock branch) perhaps I should keep the current implementation of aitask-pickrem for such environment and define a new skill 
aitask-pickremx for super restricted remote environment like claude code web

## Resolution Summary

This task was decomposed into 6 child tasks, all completed:

### Child Task Outcomes

- **t227_1 — aitask-pickweb skill**: Created a sandboxed version of aitask-pickrem for Claude Code Web. Zero interactive prompts, stores plans and completion markers in `.aitask-data-updated/` on the current branch. No cross-branch operations.
- **t227_2 — aitask-web-merge skill**: Created a local skill to merge completed Claude Web branches to main. Scans for completion markers, merges code (excluding `.aitask-data-updated/`), copies plans to aitask-data, archives tasks, and cleans up remote branches.
- **t227_3 — Board lock/unlock controls**: Added lock/unlock buttons to the board TUI task detail screen, lock indicator on kanban cards, and lock status display. Users can now pre-lock tasks before Claude Web sessions.
- **t227_4 — Lock-aware aitask-pick**: Added a read-only lock pre-check to the standard aitask-pick workflow. Warns users when a task is locked by someone else and offers force-unlock, proceed, or pick-different options.
- **t227_5 — Per-user config (userconfig.yaml)**: Introduced `aitasks/metadata/userconfig.yaml` (gitignored) with `email:` field. Updated execution profiles from `default_email: first` to `userconfig`. Added `get_user_email()` shell helper and `ait setup` integration.
- **t227_6 — Documentation**: Created website workflow guide for Claude Code Web, website skill page for aitask-web-merge, and this summary.

### t220 Verification Findings

Task t220 conclusively implemented stale lock handling:
- Structured exit codes in `aitask_lock.sh` (10=infra missing, 11=network error, 12=race exhaustion)
- `die_code()` helper in `terminal_compat.sh`
- `--force` flag and `force_acquire_lock()` in `aitask_own.sh`
- Diagnostic script `aitask_lock_diag.sh` (12 checks)
- `force_unlock_stale: true` profile setting for automated workflows

### Key Design Decisions

- **Two separate skills** (pickweb + web-merge) rather than modifying aitask-pickrem. pickrem retains full branch access for environments with more permissions; pickweb is purpose-built for Claude Web's restrictions.
- **No separate claude-web.yaml profile**: The existing `remote.yaml` profile serves both pickrem and pickweb — pickweb ignores unrecognized fields.
- **Completion marker pattern**: `.aitask-data-updated/completed_t<task_id>.json` is the contract between pickweb and web-merge for detecting completed branches.
