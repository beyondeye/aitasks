---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-11 10:37
updated_at: 2026-02-11 11:07
completed_at: 2026-02-11 11:07
---

in the aitask_board python script when a parent task board is expanded with the "x" command, the child tasks are shown below with a small padding on the left. The padding alone is not enough to visually identify the cards fo child tasks as child tasks, propose some alternatives to make the chid task card more identifiable, and after user approval implement one
