---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [scripting]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-02 10:41
updated_at: 2026-02-10 10:25
completed_at: 2026-02-10 10:25
boardcol: next
boardidx: 30
---

currently in aitask_create script, once I file reference is added, it cannot be removed: (only by editing the description manually) it would be nice in the menu when we loop adding file reference we could that the option to remove one of the file references we just added (not the previously added reference) only the current list of file references we are currently in the current point of the task description
