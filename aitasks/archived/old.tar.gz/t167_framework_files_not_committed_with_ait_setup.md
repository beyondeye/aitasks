---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [install_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-18 12:20
updated_at: 2026-02-18 14:28
completed_at: 2026-02-18 14:28
---

when running ait setup in a new project directory (with the git repo already configured, by the way) the franework files are correctly installed but they are not committed/nor added to the git repo. this is not the desired behavior: the framework files should be part of the repository. can you check what is the issue? see the following example project directory where this happend and the current status of file: /home/ddt/Work/TESTS/test_repo_bitbucket
