---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-08 11:10
updated_at: 2026-02-08 12:51
completed_at: 2026-02-08 12:51
boardcol: unordered
boardidx: 80
---

in aiboard python tui. when we have the details screen open with the detail of a task and we have the line of depends metadata selected and we press enter, we should open the detail screen for the selected dependent task.
aitask_board/aitask_board.py
