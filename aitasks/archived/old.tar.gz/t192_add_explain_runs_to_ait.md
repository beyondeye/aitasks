---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_explain, bash_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 10:47
updated_at: 2026-02-22 11:24
completed_at: 2026-02-22 11:24
---

currently the aitask_explain_runs is not documented and not linked from the ait dispatch script. need to add it. also need to update the website documentation about both in the ait dispatcher documentation anb both in the commands documentation. ask me questions if you need clarificaitons
