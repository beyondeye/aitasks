---
priority: high
effort: medium
depends: []
issue_type: feature
status: Done
labels: []
created_at: 2026-02-01 14:37
updated_at: 2026-02-01 14:37
---

I currently have a aitask-clearold skill in this repo, rewrite the flow in the skill with a bask script aitask_clear_old.sh and use it inside the skill, instead of the multistep approach that claude need to execute. ask me questions if you need clarifications

---
COMPLETED: 2026-02-01 14:43
