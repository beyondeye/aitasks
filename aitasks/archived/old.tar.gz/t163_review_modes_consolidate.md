---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_review, claudeskills]
created_at: 2026-02-18 00:17
updated_at: 2026-02-18 22:00
completed_at: 2026-02-18 22:00
boardcol: now
boardidx: 10
---

review guides for the aitask_review skills are currently just specification markdown files in the reviewguides directory. there is not AI way to organize them, cross check them, merge them prune them. it would be useful to have a way to 1) find all reviewguides specific to some environment 1)make the llm split them in sections 2) compare them 3) allow to choose which part of which for a final merged review specs, 4) check for consistency and contradicting instructions 5) validate them for best practices of wrtiing specs/skills 6) automatically categorize them when a new spec/best practice/architecture file is added. to make all this easier it is not enough to have a single metadata field (environment) to classify the best practices. also there are actually specialized tools (linting tools) for most environment that can find issues much faster, so perhaps better to keep most general rules. what specilized liinting tools cannot do is scan file for possible real issues and bugs, code repetions, code smells. so we get back to the problem of a tool for classifying, grouping, merging, remove duplicate sections for descriptions ot best practices and, conventions, code style, for the reviewguides markdown file. having a labels field metadata in addition to current environment (and perhpas other fields, like type: style, code-smell, etc) could help. Also I am not sure how to structure this tool, if a part of this classification tool can be offloaded to a bash script. probably better to start from pure skill workflow, and refine it later. the input for the skill is a single new file to process that will be compoared to existing files rules, if it can be merged, or complement existing files, marking common parts that are redundant. so the sequence of the operations of the skill 1) classify the new reviewguide file (add proper metadata fields similar based of fields of existing reviewguide files 2) assign new labels subenv labels 3) once it is classified compare to existing file in same environemnt. add a field with the name of most similar file as candidate for merging/resplitting. then in further phase or skill allow a reviewguide found similar to another to be 1) merged 2)respltted: common parts merged and reassigned to one of the to avoid duplicates. In conclusion what is missing from the current system: more metadata fields that are assigned with initial analysis and comparision of new added file with existing file, that will result in classifying similar reviewguide file together (same subdir or close subdir . and the a separate skill to process two similar reviewguide files and propose to - or merge -or remove the similar part that are present in the two and assign to only one of them.
