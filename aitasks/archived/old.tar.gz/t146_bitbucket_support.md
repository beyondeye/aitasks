---
priority: medium
effort: medium
depends: ['136']
issue_type: feature
status: Done
labels: [claudeskills, gitremote, scripting]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 11:32
updated_at: 2026-02-18 13:08
completed_at: 2026-02-18 13:08
boardcol: now
boardidx: 30
---

See `aidocs/gitremoteproviderintegration.md` for the full checklist of files and sections to update when adding a new git remote provider.

see task t136 for details. we want to add same features also for bitbucket. the problem is that bitbucket does not have an official cli tool similar to gh. yet there is a community developed clit tool called bkt. the features we want to implement should be probably based on this bkt cli tool
