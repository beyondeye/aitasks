---
priority: high
effort: low
depends: []
issue_type: bug
status: Done
labels: [install_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 13:05
updated_at: 2026-02-17 13:38
completed_at: 2026-02-17 13:38
---

I am currently trying to run create_new_release: i have changelog with 0.4.0 entry but when I run create_new_release.sh and selecte 0.4.0 as new release number it says that no changelog entry found for 0.4.0. can you fix the issue?
