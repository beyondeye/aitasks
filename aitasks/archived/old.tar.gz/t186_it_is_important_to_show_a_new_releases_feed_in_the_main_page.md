---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [web_site]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-20 00:14
updated_at: 2026-02-22 19:42
completed_at: 2026-02-22 19:42
boardcol: now
boardidx: 60
---

Task name (short, will be sanitized): It is important to show a new releases feed in the main page of the website, or perhaps better in the top menu, as "blog" entries with link to github full release notes and a main new features descriptions that summarize what changed. I don't if the creation of this blog entries should be automated with claude, I can probably do it manually? need to think about it perhaps define a custom command that is not exported to the release tarball that fetch the last release version release notes, create a "blog" entry in the hugo site (check docsy docs on how to do it) https://www.docsy.dev/docs/content/adding-content/ and ask the user what to change, the blog entry should written in "informal" language highlighting main feature with link to github full release motes
