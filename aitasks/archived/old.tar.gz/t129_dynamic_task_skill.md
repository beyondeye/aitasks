---
priority: medium
effort: high
depends: []
issue_type: feature
status: Done
labels: [claudeskills]
created_at: 2026-02-15 08:44
updated_at: 2026-02-19 23:45
completed_at: 2026-02-19 23:45
boardcol: now
boardidx: 20
---

There cases where defining an aitask first and then running aitask-pick, it justs feels too much "friction". we just want some specific small work just get done. or perhpas, another scenario is that we actually don't what we want to do. we just need to "explore" some problem and some specific parts of the code-base (like for refactoring tasks). in all these case we don't have some aitask defined in advance. still we don't want to loose all the aitask machinaery available when we run aitask-pick, like the option to automatically handle git worktree for feature implementation and documentation of a task execution that is embededded in an aitask plan and final implemntation detaials that are written on task completion in aitask-pick, or the potential automatic handling of task decompostion in child-tasks. In brief we want to start working without a precise task framework but at some state we want to switch back to the regular aitask-pick workflow. so we want to define a new skill, that basically subsitute the part of aitask-pick where we choose an existing aitask with an exploration phase that at some point we want to close with the creation of some task definition (automated, dome by the new skill flow) and swich back to the aitask-pick flow. In addition to the "user-driven" exploation use case for this "dynamic-task-pick" workflow, a similar workflow that also rquire dynamic creation of aitasks, in we want to impleemnt an automatic code-review workflow where claude code explore the code-base, with some hints by the user about where to concentrate and on what aspect of the code, and then automatically create an aitasks anf get back to aitask-pick workflow. in both these scenarios there should be the options to go straight to implementation after the task creeation or abort the flow and keep it to for a later aitask-pick. I am not actaully sure about this, if there should be an option to just go on with implementation of the created aitask or wait for a later aitask pick. but probably the two options should be available, the user will decide, based on current context usage. in order to support this skills (an explore skill where the user still mainly drive tha task creation, and review skill where the task creation is more somthing that claude code define according to rule-based user requriments (code conventions, reduce code duplication, refactor code components), in order to avoid duplication for workflow steps between aitask-pick and these new workflow should refactor aitask-pick is some subcomponents that can be referred to both by the original aitask-pick skill and the new skills,   THIS IS A VERY COMPLEX TASKS, SO WE SHOULD SURE NEED TO SPLIT IT IN CHILD TASKS. ask me questions if you need clarifications
