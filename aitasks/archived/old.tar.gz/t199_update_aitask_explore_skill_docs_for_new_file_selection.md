---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_explore]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 13:07
updated_at: 2026-02-23 09:04
completed_at: 2026-02-23 09:04
---

whe integrated the new user_file_select skill in the xplore skill, need to update the documentation of the explore skill about the new file selection mechanism
