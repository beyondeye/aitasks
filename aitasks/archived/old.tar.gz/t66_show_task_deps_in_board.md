---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitasks, aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-09 09:50
updated_at: 2026-02-10 10:45
completed_at: 2026-02-10 10:45
boardcol: now
boardidx: 70
---

in aitask_board python script currently each task box in the main board screen have a line status that show the ready/blocked status, in the same line we should also show the list of tasks from which this tasks (not yet executed) dependens on
