---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask-create]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-26 08:39
updated_at: 2026-02-26 10:15
completed_at: 2026-02-26 10:15
---

it has happened to me many times that I wrote the task descrption wrongly in the task name. add handling for this case. that is if we identify that the task name is very long lets say more than 50 characters the the script should ask? you entered a long text is this part of the task description? if the user answer yes then tell the user; no problem i will keep it for the the description, what should be the actual task name? and reask the task name and then initialize the description with the text the user entered before and tell the user that this was done and then go on with regular add descirption/add files loop
