---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [web_site, aitask_changelog]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 23:32
updated_at: 2026-02-19 23:51
completed_at: 2026-02-19 23:51
---

Every developer of an (open source) projects has the problem of documenting what it in a new release of the project, this is  a seriously annoying task. document the workflow of using the aitask-changelog skill to automatically generate changelog and release notes for a new release of a project, show the example on how this works for the aitasks projects, with the aitask-changelog integrated with create_new_release.sh script and the github actions triggered when a new release is created
