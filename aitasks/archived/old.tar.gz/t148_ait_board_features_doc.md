---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 11:56
updated_at: 2026-02-17 14:30
completed_at: 2026-02-17 14:30
boardcol: now
boardidx: 60
---

The ait board python TUI has a lot of features, but is not currently documented at all, it should have its own markdown document file in docs/ with TOC, place for actual pictures when relevant, pictures will be provided by the user, just put placeholder in the markdown file: througly analize the source and create full documentation for the board divided in 1) tutorial on how to use 2) how to guides 3) feature reference. ask me questions if you need clarifications
