---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [codebrowser]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-26 09:28
updated_at: 2026-02-26 13:05
completed_at: 2026-02-26 13:05
---

current the ait codebrowser does not handle properly the screen layout according to available screen estate: the size of the browser tree and code column do not resize when thers is less screen space. this is less of a problem for the source tree and the code pane itself, the problem are the additional "columns" like the annotation columns that is invisble even if toggled on even if in theory even if the screen space is limited it would be reasonable to show the column with the task annotation by slighlty resizing the code column (and perhaps slightly adaptint the the tree browser width for smaller screens. need to think of solution for this issue
