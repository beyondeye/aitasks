---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [scripting]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 12:49
updated_at: 2026-02-17 12:53
completed_at: 2026-02-17 12:53
---

after running the release new release flow that is basically running /aitask-changelog and create_new_release, we should also run ait zipold: update documentation of Release process in the developement doc
