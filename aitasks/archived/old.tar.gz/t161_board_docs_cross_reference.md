---
priority: medium
effort: low
depends: []
issue_type: documentation
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 22:39
updated_at: 2026-02-17 22:45
completed_at: 2026-02-17 22:45
---

check the README.md and docs file, when operation that are described in script documentation can be also done within the task board cross reference the documentaton on how to do it from the task board, in general where we reference the task board add reference to the full task board documentation. currently even in the doc of ait board command there is no reference to the actual board documetnation
