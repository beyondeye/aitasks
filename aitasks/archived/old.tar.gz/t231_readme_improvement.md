---
priority: high
effort: medium
depends: []
issue_type: bug
status: Done
labels: []
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 10:02
updated_at: 2026-02-24 10:14
completed_at: 2026-02-24 10:14
---

the README.md file in the aitask repository got lost in some the last commits now it is empty, please recover it from git history. also on the top of the readme I would like to add more badges (the docs badges only was present in the readme, before it god overwritten) I would like to add the badge for stargazer (see for example https://github.com/github/spec-kit) also I would like to add the project logo at the top, and formatted punch line (similar as it is done in spec-kit) also I would like nicer readme sections title like it is done here https://github.com/steveyegge/beads
