---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-09 09:46
updated_at: 2026-02-10 12:30
completed_at: 2026-02-10 12:30
boardcol: now
boardidx: 90
---

in aitask_board python script, it would be nice to have an option to "explode" tasks with children: when a task with children is selected, add a keyboard shortcut "x" the explode or implode that task. where a parent task is "exploded" then it will show under it the boxes for all child tasks.the child tasks will be display with the same format as a normal task but with a small margin at the left of the box so that that is mmediatelly visible that they are child tasks( a margine of one character is enogh). not that child tasks should be selectable, but they cannot be moved from column to column, or reordered. they are always shown below their parent task and they alway move from column to column with their parent task
