---
priority: medium
effort: medium
depends: []
issue_type: performance
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-26 15:38
updated_at: 2026-02-26 16:39
completed_at: 2026-02-26 16:39
boardcol: now
boardidx: 30
---

interacting with the ait board can become sluggish, when a lot of tasks are present in the board. add the option tocollapse expand column content. add a button (single emoji or arrow up/down based button) in the column title that when clicked trigger collapse and expland. also add a "edit" button (use proper emoji) than when clicked will trigger the edit column dialog that now is triggered by clicking anywhere in the column title. when a column is colpased, reduce its witch to the minimum to show its title with the number of tasks inside it put in a speparate line. tasks in collapsed columns will not be rendered nor checkd for lock status. also add in board config wich columns are expanded or collapsed, no keyobard shortcuts for expand or collapse a column: only command in command palette or mouse actions. need also to updaate ait board documentaiton about this new feature. this task is a follow up of the task t261. which also was about ait board performance
