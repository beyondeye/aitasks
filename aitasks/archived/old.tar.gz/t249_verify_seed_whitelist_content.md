---
priority: medium
effort: low
depends: []
issue_type: chore
status: Done
labels: [install_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 16:22
updated_at: 2026-02-25 16:31
completed_at: 2026-02-25 16:31
---

verify that the seed/claude_settings.local.json contains white-list definitions for all aiscripts used by skills
