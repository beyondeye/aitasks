---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 10:52
updated_at: 2026-02-22 12:09
completed_at: 2026-02-22 12:09
---

currently in the python task board, we have the r refresh shortcut for refreshing the board with the current actual task files existing and their status. it would be nice to have a the feature to autorefresh this list every 5 minutes. perhaps we can add a settings screens for the ait board where we can add settings like this one (autorefresh 5 minutes/ other interval, 0 for no autorefresh) and store the settings in board_config.json. ask me questions if you need clarificaiotns
