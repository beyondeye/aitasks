---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [web_site]
created_at: 2026-02-19 10:26
updated_at: 2026-02-19 15:14
completed_at: 2026-02-19 15:14
---

create a hugo website that automatically deploy on github pages with a git workflow that at release copy the current docs and website to ghpages branches where the hugo website is and automatic build with hugo and deploy to ghpages the static web site

see https://gohugo.io/ . as hugo them use the docsy theme, see https://www.docsy.dev/docs/

the github repository of the aitasks project is at https://github.com/beyondeye/aitasks, if need to be linked in the documentation site. my main github page is https://github.com/beyondeye my X username is (currently) DElyasy72333

this is a complex task please split it multiple child tasks
