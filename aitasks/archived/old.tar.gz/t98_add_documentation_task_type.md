---
priority: medium
effort: low
depends: []
issue_type: bug
status: Done
labels: [aitasks, bash]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-12 10:14
updated_at: 2026-02-12 10:23
completed_at: 2026-02-12 10:23
---

add the "documentation" task type in aitasks/seed/task_types.txt. update README.md if needed, update also in local metadata file
