---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 12:06
updated_at: 2026-02-22 12:54
completed_at: 2026-02-22 12:54
---

we have just added a new settings screen and the feature to ait board to autorefresh the current tasks (by default every 5 minutes). update the ait board documentaiton in web site about the auto refresh feature and about the settings screen
