---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 12:09
updated_at: 2026-02-19 12:49
completed_at: 2026-02-19 12:49
---

in the aitask_board python script in this project, in the main screen, in the card of a parent task with children, there is no visible status about any of the chidren being currently in the implementing status and indication of WHO is implementing. only by expanding children this is information can be obtained. this is not good UX. for a parent task with any of the children currently in implementing status, don't show the status line (Ready) but instead show the list of child tasks with the implementer email (one per line)
