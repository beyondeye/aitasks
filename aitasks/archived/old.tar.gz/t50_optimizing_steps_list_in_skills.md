---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [claudeskills]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-05 16:41
updated_at: 2026-02-05 18:05
completed_at: 2026-02-05 18:05
---

in aitask-pick skill in this repo all steps and substeps of the workflow are numbered. I am afraid that this is not optimal. this consume llm context memory for probably no benefit. am I right about this? where the subteps numbering could be avoided in workflow? or it is better to keep the substep numbering? by removing substep numbering I mean to subtitute - 1.1: some substep description with - some substep descrption
