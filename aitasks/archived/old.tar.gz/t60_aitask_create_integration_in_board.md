---
priority: high
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitasks, aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-08 14:32
updated_at: 2026-02-10 11:46
completed_at: 2026-02-10 11:46
boardcol: now
boardidx: 40
---

I would like to integrate aitask_create bash script for creating new tasks inside the aiboard python TUI. there could a simple keyboard shortcut "c" that spawn a new terminal and run the aitask_create script. ask me questions if you need clarifications
