---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_explain]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 13:09
updated_at: 2026-02-23 14:45
completed_at: 2026-02-23 14:45
boardcol: now
boardidx: 30
---

we have created a new ad-hoc user-file-select skill to find files to feed to the explore and explain skills, need to update the documentation of the explore skill about the new flow for choosing files
