---
priority: medium
effort: low
depends: []
issue_type: documentation
status: Done
labels: [codexcli,  geminicli]
created_at: 2026-02-22 11:59
updated_at: 2026-02-22 12:00
completed_at: 2026-02-22 12:00
---

Add extraction scripts and reference documentation for Codex CLI and Gemini CLI tool capabilities. Includes a generated Codex CLI tools reference and two bash scripts that auto-generate tool documentation by querying each CLI.
