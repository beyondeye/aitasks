---
priority: low
effort: low
depends: []
issue_type: documentation
status: Done
labels: [documentation, ui]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 22:31
updated_at: 2026-02-25 00:19
completed_at: 2026-02-25 00:19
---

Document the new lock/unlock controls in the ait board TUI in the website docs (board documentation section). Include: 1) Lock status display on task detail screen 2) Lock/Unlock button usage 3) Lock indicator on kanban cards 4) How-to guide: locking a task before picking it for Claude Web execution 5) How-to guide: using locks to signal to other users/AI agents that you are working on a task
