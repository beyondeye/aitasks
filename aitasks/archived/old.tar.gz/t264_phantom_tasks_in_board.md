---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-26 16:44
updated_at: 2026-02-26 17:18
completed_at: 2026-02-26 17:18
---

currently t261 is "phantom" task, it is actually has already been implemented aand archived. but for some reason the board still has it check what is the git status of the file, when retrieving it i get: boardidx: 20
