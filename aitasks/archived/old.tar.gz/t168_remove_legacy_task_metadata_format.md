---
priority: medium
effort: medium
depends: []
issue_type: refactor
status: Done
labels: [bash_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-18 14:27
updated_at: 2026-02-18 15:12
completed_at: 2026-02-18 15:12
---

several aitask bash scripts in aiscripts still support legacy metadata format for tasks (for example aitask_ls) please check all script and remove support for this legacy format. clean up script code after this simplification
