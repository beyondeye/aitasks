---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-05 18:03
updated_at: 2026-02-24 21:58
completed_at: 2026-02-24 21:58
boardcol: now
boardidx: 60
---

in the aitask-pick skill we have  a verify build step that is specific for an android project. I want this skill to more generic. need to find a way to define the verify build step more geric depending on the project type.
