---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 15:10
updated_at: 2026-02-25 15:42
completed_at: 2026-02-25 15:42
---

currently in the ait board with can unlock a task, but when unlocking a task, if it is in implementing state and assigned to somebdoy this metadata is kept (that is status: implementing, assigned_to field). when unlocking such type of tasks, there should be an option (question dialog for confirmation) to move back the task status to ready (with explanation you are going to reset assignment from: xxx*mail.com and status to ready. or something like this
