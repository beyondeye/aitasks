---
priority: medium
effort: low
depends: []
issue_type: bug
status: Done
labels: [aitasks, claudeskills]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-04 13:31
updated_at: 2026-02-05 12:18
completed_at: 2026-02-05 12:18
---

need to update the aitask-pick skill to explicitly have instructions to delete child task directory and child plan directories whan all child tasks has been completed and archived. don't leave empty child tasks subdirectories in aitasks, and not empty child task plans directories in aiplans
