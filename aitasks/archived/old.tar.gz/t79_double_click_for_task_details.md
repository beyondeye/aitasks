---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-10 12:25
updated_at: 2026-02-10 12:29
completed_at: 2026-02-10 12:29
---

in aitask_board python script is it possible to add the option to open a task card detail with double click in addition to pressing enter
