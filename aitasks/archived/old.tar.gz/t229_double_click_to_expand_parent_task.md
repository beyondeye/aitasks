---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 08:17
updated_at: 2026-02-24 08:28
completed_at: 2026-02-24 08:28
---

in the ait board currently when double clicking a task card we open the card details. I want to change the behavior when clicking parent tasks with children that are collapsed. In such case the double click action should expand the child list
