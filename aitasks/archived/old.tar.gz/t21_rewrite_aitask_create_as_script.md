--- effort:med pri:med
I want to rewrite the aitask-create slash command to use an actual bash script, for efficiency and features: all the steps in in skill definitions should be replaced by a single bash script, for fuzzy finding files to be referenced in task definition you should use fzf (run man fzf for detailed) this fzf is cli tool for fuzzy finding files

---
COMPLETED: 2026-02-01 11:33
