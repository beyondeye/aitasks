---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [web_site]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-20 00:18
updated_at: 2026-02-24 11:48
completed_at: 2026-02-24 11:48
boardcol: now
boardidx: 50
---

the current web_site about page is horrible, propose options on how to improve it: what information to put here how to format, project statistics (github start increase). whatever: currently is horrible, contein info already in main site page that should be there
