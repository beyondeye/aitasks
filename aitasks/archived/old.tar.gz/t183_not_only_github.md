---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [web_site]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 23:04
updated_at: 2026-02-19 23:38
completed_at: 2026-02-19 23:38
---

We have added support for gitlab and bitbucket remotes in skill and bash scripts used to integrate workflows based on gitlab/github/bitbucket issues, with workflow based on aitasks, in every place where we refer github only we need to update the documentation to reference also gitlab and bitbucket
