---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [codebrowser]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-26 08:18
updated_at: 2026-02-26 08:50
completed_at: 2026-02-26 08:50
---

currently in the python codebrowser it is possible to move the selected line curson only with top and down arrow and select line only with shift+arrow: add support for selecting line with mouse left clich and select line with left mouse click pressed + mouse move left/donwn
