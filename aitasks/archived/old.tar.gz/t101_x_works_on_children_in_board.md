---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitasks, aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-12 12:49
updated_at: 2026-02-12 14:05
completed_at: 2026-02-12 14:05
---

currently in the aitask_board python script there an x keyboard shortcuts that when a parent task card is active allow to expand collaps its children. for better usability I would like this command to be active also when one of the child tasks is selected that is pressing x will collaps children card if a child task is selected
