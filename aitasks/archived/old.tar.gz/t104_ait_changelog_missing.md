---
priority: medium
effort: low
depends: []
issue_type: bug
status: Done
labels: [scripting, aitasks, bash]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-12 16:17
updated_at: 2026-02-16 11:41
completed_at: 2026-02-16 11:41
boardcol: now
boardidx: 30
---

ait changelog subcommand missing from ait shell script help text
