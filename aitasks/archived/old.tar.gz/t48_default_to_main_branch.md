---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-05 16:16
updated_at: 2026-02-05 16:19
completed_at: 2026-02-05 16:19
---

in aitask-pick claude code skill when we ask he user if he wants to create a git worktree or work on task in current branch, currently it says new worktree as recommended and it is default choice. change dfault choice to current main branch and and instead of (recommended) text for worktree option, show (recommended for complex features or when working on multiple in parallel on multiple features)
