---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [claudeskills, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-04 23:15
updated_at: 2026-02-04 23:38
completed_at: 2026-02-04 23:38
---

The aitask-pick has evolved quite a bit with many added sections, I need to verify its logic and simplify redundant part and try to make it non-ambiguous. also it must be clear that when implementation is completed claude must not commit chnages without asking for user approval. the user need to be given opportunity to review the changes and test them, before claude commit them
