---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [claudeskills, scripting, aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-17 23:05
updated_at: 2026-02-18 10:19
completed_at: 2026-02-18 10:19
---

add missing default task types from conductor task types: feat: New feature

the missing task types are style, test, chore. I am not sure if should stick to the long task type name we currently use or move to shorter task types. in any case need to make sure there is support for all new default task types across scripts, boards, skills. probably the infrastructure allready support this
