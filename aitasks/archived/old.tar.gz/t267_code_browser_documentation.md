---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [codebrowser]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-26 23:05
updated_at: 2026-02-26 23:42
completed_at: 2026-02-26 23:42
---

analyze ait codebrowser code and write documentation for it in the website documentation, model the style of the docs with the docs/board documentation also move both the new page CodeBrowser and Board to be subpages of a new page TUIs, make sure that this does not break references to the board page in existing documentation. for the code browser documentation I have provided 3 screenshots. they can be found in the imgs/aitask_codebrowser_*.svg one image is only with code column, on with code column and anntations and finally one with code, annotations and plan details. explain all the possible howtos, what can be done with the codebrowser. also cross links the skill aitask_explain and the codebrowser documentation and the bash scripts to mange aiexplain runs datails, also reference the codebrowser in the workflows that talks about explaining code. ask me qeustions if you need clarifications
