---
priority: high
effort: low
depends: []
issue_type: bug
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-11 16:02
updated_at: 2026-02-11 16:15
completed_at: 2026-02-11 16:15
---

the aitask board python script the n keyboard shortcut should spawn a new terminal running ait create: it does not work after the refactoring of path of aitask bash scripts
