---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-16 15:21
updated_at: 2026-02-16 16:52
completed_at: 2026-02-16 16:52
---

add support for deleting tasks in the aitask python board TUI. implement it as a button in the task detail screen. only tasks that are not in the implementing status can be deleted. for making space for the new button change the label Edit(System Editor) to simply EDIT. when the user press delete button show a dialog to to ask for confirmation. ask me questions you need more clarifications
