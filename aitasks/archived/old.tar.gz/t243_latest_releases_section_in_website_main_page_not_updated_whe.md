---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [release_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 10:49
updated_at: 2026-02-25 11:24
completed_at: 2026-02-25 11:24
---

I have just released version 0.7.0 and I just noticed that the Latest release section in the website main page was  not updated: it still shows 0.6.0 as latest release. there is any way to autoupdate this list on release? what is wrong?
