---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitask_fold, claudeskills]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 22:48
updated_at: 2026-02-19 23:25
completed_at: 2026-02-19 23:25
---

verify that documentation for aitask-fold skill is up-to-date: add a workflow page in documentation for the workflow of folding one or more tasks in another one (it can happen that the same task was introduced by multiple user or new task was defined that encompasses other ones). this the opposite of the workflow of splitting a task, but it happens for complete different reasons, usually, not because of task complexity, but for more efficient execution of correlated tasks
