---
priority: low
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [website]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 19:34
updated_at: 2026-02-24 23:25
completed_at: 2026-02-24 23:25
---

Create website/content/docs/skills/aitask-pickweb.md with skill overview, workflow description, and a reference to the Build Verification subpage at ../aitask-pick/build-verification/. Follow the pattern of existing skill pages like aitask-pick/_index.md.
