---
priority: medium
effort: low
depends: [t196_1]
issue_type: documentation
status: Done
labels: []
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 11:33
updated_at: 2026-02-22 12:30
completed_at: 2026-02-22 12:30
---

Add documentation for the aitask-wrap skill to the Hugo/Docsy website. Document the skill among the other skills pages: what it does, when to use it, usage examples, and how it integrates with the aitasks workflow. Follow the existing documentation structure and style used for other skills.
