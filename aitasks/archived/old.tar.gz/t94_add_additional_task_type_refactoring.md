---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitasks, bash]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-11 16:05
updated_at: 2026-02-11 18:39
completed_at: 2026-02-11 18:39
---

currently only allow task types are feature and bug, add additional type: refactor. make sure to update aitask_update and aitask_create and all other bash script to support the new type
