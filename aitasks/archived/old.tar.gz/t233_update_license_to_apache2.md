---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [legal]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 14:13
updated_at: 2026-02-24 14:32
completed_at: 2026-02-24 14:32
---

I would like to update the license of the project from mit + commons clause to apache 2.0 plus commons clause. starting from the github repository and then in all places in the website documentation where the license is mentioned:  the following is the text for the license file

Licensor: Dario Elyasy

💡 Why this is better for aitasks

I have received this suggestion from gemini, please verify that it make sense and the license language seems correct

here is the motivation gemini gave for the change please verify and confirm:

Advantages of using Apache 2.0 as the base
