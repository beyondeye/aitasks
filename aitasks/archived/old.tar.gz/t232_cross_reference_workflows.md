---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [claudeskills, bash_scripts]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 11:59
updated_at: 2026-02-25 08:39
completed_at: 2026-02-25 08:39
boardcol: now
boardidx: 10
---

it would be nice at the end of each skill doc page in docs/skills, at the end of the skill reference to cross reference the workflows where the skill is central, in a similar way as this is done currently for the aitask-explain skill,
