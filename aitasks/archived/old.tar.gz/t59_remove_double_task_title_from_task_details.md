---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-08 13:02
updated_at: 2026-02-08 13:28
completed_at: 2026-02-08 13:28
boardidx: 10
---

in aitask_board python TUI when I open the details of a task, the task name (title) is shown twice: it is shown at the top and also before the task description. I would like to keep only the top one. and remove the one before the description
