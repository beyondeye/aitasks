---
priority: medium
effort: high
depends: []
issue_type: documentation
status: Done
labels: [aitasks]
created_at: 2026-02-12 10:23
updated_at: 2026-02-12 14:13
completed_at: 2026-02-12 14:13
---

the current content of README.md is outdated regarding the details of what aitask scripts are available and what skills and also what each script and skills. I want to review one by one each available aitask bash script and each available aitask skills and add update brief and detailed documentation for each them. review the full details of the source code of the bash scripts and the skills and what they do. propose me to review the new edocumentation and where it will be added in the readme and the update the readme. define a child aitask for each bash script and each skill so that we can run theaitasks in parallel to update the documentation. ask me questions if you need clarifications
