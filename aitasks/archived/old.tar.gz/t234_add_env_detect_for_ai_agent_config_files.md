---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_reviewguide]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-24 18:30
updated_at: 2026-02-24 18:42
completed_at: 2026-02-24 18:42
---

I have just added an aigents environment for guides on how to write skills, I need to update aitask_review_detect_env.sh for code to detect files that are aigents (like geminicli codexcli, opencode, caludecode) configuation files, like custom commands definitions, skills, AGENTS.md, CLAUDE.md and so on, also the new guide added skill_authoring_best_practices.md, I am not sure that it has been assigned the correct labels and types, the current label vocabolary is probably missing labels for this kind of "code", need to check if it needs to be updated (the label vocabulary, the type vocabulary, and the specific values for type and labels assigned to this specific guide). this is guide specific for skills, also when all the process described above is complete I would like to add this skill authoring guide to the seed guides distributed with aitasks and also update the default labels/type with the new labels/types introduced (if any)
