---
priority: medium
effort: low
depends: []
issue_type: documentation
status: Done
labels: [aitasks]
folded_tasks: [113]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-13 00:18
updated_at: 2026-02-17 10:33
completed_at: 2026-02-17 10:33
boardcol: now
boardidx: 50
---

add documentation of recommended claude plugin: https://github.com/jarrodwatts/claude-hud because controlling context is fundamental for good task execution, this is also one one the reason of the design of aitasks based on small interconnected tasks

## Merged from t113: claudehud_suggestion

add suggesttion in readme to install something like claude hud plugin to view courrent context usage in realt time. one of the advatange of decomposing work in small connected task is that we can reduce context usage that make claude code effectively more intelligent monitoring context usage in real time is very important: link to claude hud: https://github.com/jarrodwatts/claude-hud

## Folded Tasks

The following existing tasks have been folded into this task. Their requirements are incorporated in the description above. These references exist only for post-implementation cleanup.

- **t113** (`t113_claudehud_suggestion.md`)
