---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [release_scripts, web_site]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-20 00:23
updated_at: 2026-02-20 00:28
completed_at: 2026-02-20 00:28
---

currently when a new release is created the deploy to hugo site workflow fails with a security issue: Tag "v0.5.0" is not allowed to deploy to github-pages due to environment protection rules. please help trouble shot thit issue
