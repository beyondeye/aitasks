---
priority: high
effort: high
depends: []
issue_type: feature
status: Done
labels: [aitasks, aitask_board]
created_at: 2026-02-06 15:34
updated_at: 2026-02-08
completed_at: 2026-02-08
---

I would like to create a multiplatform ui for managing aitasks. it should have a small executable footprint and be executable from platform like windows/linux/macos out of the box. I wanthinking about python but also if there are other frameworks that I am not considering you can suggest one
