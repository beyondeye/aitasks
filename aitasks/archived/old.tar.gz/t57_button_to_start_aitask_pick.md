---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-08 11:16
updated_at: 2026-02-08 11:56
completed_at: 2026-02-08 11:56
boardidx: 10
---

Add a button in aitask_board task detail screen the button is "Pick" that when clicked, it opens a new terminal session and launch claude code with the user command /aitask-pick <selected task> check in the claude code documentation how to properly define the command line args for claude code for doing this
aitask_board/aitask_board.py
