---
priority: medium
effort: medium
depends: []
issue_type: refactor
status: Done
labels: [aitask_pick, task_workflow]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-25 12:29
updated_at: 2026-02-25 22:37
completed_at: 2026-02-25 22:37
---

the task-worflow skill is a big file, I would to split it in mulitple files that are loaded on demand: see the cluade skill best praactices official documentation on how to do it properly. one idea is for example to move the abort procedure to a separate file that is loaded on demand.
