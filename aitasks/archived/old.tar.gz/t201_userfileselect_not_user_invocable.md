---
priority: medium
effort: low
depends: []
issue_type: bug
status: Done
labels: [claudeskills]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-22 13:30
updated_at: 2026-02-22 14:21
completed_at: 2026-02-22 14:21
---

we have introduces a new user-file-select skill that is used by the aitask-explore skill and aitask-explain skill. this new skill is for claude code internal use only it should not be user invocable
