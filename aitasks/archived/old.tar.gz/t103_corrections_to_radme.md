---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-12 14:34
updated_at: 2026-02-12 14:47
completed_at: 2026-02-12 14:47
---

the project README.md has been updated with a lot of additional information. need to add TOC before the Command Reference section (please generate it). also please make the following addition fixes: in the aitask-pick skill initial desccription need to add that this is the central part of the framework and of the workflow.  Also the Execution Profiles section should be subsection of the aitask-pick skill description.   another change to do is that the Claude Code permission section should be a subsection of ait setup command descriptions. also the ai-setup command description should be the first in the list of commands, and its should docuentation should be referenced in the Quick install section. the platfrom support sections and related sections with known issues shold be before the Quick Install section.    Finally the release process is know wrong. for release what should be done is first to run /aitask-changelog to update the changelog and then run the create_new_release.sh
