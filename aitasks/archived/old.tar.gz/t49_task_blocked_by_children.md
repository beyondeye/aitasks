---
priority: medium
effort: low
depends: []
issue_type: bug
status: Done
labels: [aitasks]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-05 16:31
updated_at: 2026-02-05 16:46
completed_at: 2026-02-05 16:46
---

when running aitask-pick skillit shouws task t42 blocked by children status, and does not aldoes not list the task in the list of tasks to work on, unless i enter its number manually. can you check why this happeneing? this is not desired beahvior the status of the task is ready and the blocked by children status only means that there are children that need to be implemented so its should be possible to pick the task in the list
