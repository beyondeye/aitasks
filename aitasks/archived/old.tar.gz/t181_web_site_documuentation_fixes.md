---
priority: medium
effort: medium
depends: []
issue_type: documentation
status: Done
labels: [web_site]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 19:34
updated_at: 2026-02-19 22:29
completed_at: 2026-02-19 22:29
---

after moving the docs files to the website/content/docs directory there are severeal issue to solve: 1) the documnetation map in the docs/README.md file is incomplete: not all the pages and subpages are listed there for reference. 2) in the main documentation page of the docs site there icons of supported platform: remove this. 3) I want to add a section in web page documentation that is called "Overview", that basically replicate the "The Challenge". "Core Philosophy", "Key Features and architecture" from the main README.md in the github repo. this should be the first section of the documentation in the web site 4) in the main README.md in the github repo, in the Documentation section only the first link Documentation Website link to the website, all the link to documentation subsection link to file in the github repo: this is not right: also the links to the documentaiton subsections should link to the website
