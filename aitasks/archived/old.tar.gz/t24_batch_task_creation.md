---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [asdasd]
created_at: 2026-02-01 15:52
updated_at: 2026-02-01 15:52
---

I wan to change the script aitasks_create.sh in the following way 1)in the of labels to add to the task, in addition to the list of exisitng labels and the option add new label, add option Done adding labels. 2) I want to make the aitasks_create to be callable in batch mode by defining the parameters for the new task on the command line and setting the paraeters that are not explicitly defined with sensible default values. thurpose of this feature is allow an ai agent to autonomously enque tasks to be executed later

the command line options (for fields that are relevant to the options of the bd cli tool: run bd create --help to see the options. ask me questions if you need more clarifications

---
COMPLETED: 2026-02-01 16:15
