---
priority: medium
effort: low
depends: []
issue_type: documentation
status: Done
labels: [aitask_board, web_site]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-19 23:16
updated_at: 2026-02-19 23:20
completed_at: 2026-02-19 23:20
---

currently in the board documentation we have at the beginning a prerequeisite sections. this section can be removed. everything is handled automatically by ait setup. remove the preprequisite section
