---
priority: medium
effort: low
depends: []
issue_type: feature
status: Done
labels: [aitasks, bash]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-11 11:24
updated_at: 2026-02-11 11:28
completed_at: 2026-02-11 12:00
boardidx: 10
---

rename the aitask_import.sh script to aitask_issue_import script make sure that that the help text in the script reflect the new name.

## Completion Notes
Completed on 2026-02-11. Renamed file and updated all 8 self-references in the help text.
