---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [aitasks, bash]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-12 14:19
updated_at: 2026-02-12 16:11
completed_at: 2026-02-12 16:11
---

when we run the ait setup script, we should add a check if there is already a git repository intialized in the current directory and if not offer to create one. then with confirmation ask to add and commit to the git repo the aiscript directory and the aitasks/metadata directory the added aitask claude code skills. because the aitask framework is designed to be part of the git repo of the project. still ask for confirmation from the user but if he refuses ask gain and say that aitask frameworks is designed to be part of the project repostiory, still the user should be able to refuse
