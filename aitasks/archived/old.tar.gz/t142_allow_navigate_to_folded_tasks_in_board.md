---
priority: medium
effort: medium
depends: []
issue_type: feature
status: Done
labels: [aitask_board, aitasks_explore]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-16 17:16
updated_at: 2026-02-16 19:09
completed_at: 2026-02-16 19:09
---

in the python ait board script in the screen where we show a task detail currently we ignore the metadata field about folded_tasks that was introduced recently in in the aitask_explore skill. I would like to be able to show in task details the list of folded tasks like we currently shown the depends metadata field and allow to open any of the linked folded_tasks like we currently we can do for child tasks or task dependencies
