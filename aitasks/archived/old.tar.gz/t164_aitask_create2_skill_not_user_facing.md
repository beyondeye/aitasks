---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [claudeskills]
assigned_to: dario-e@beyond-eye.com
created_at: 2026-02-18 08:09
updated_at: 2026-02-18 09:45
completed_at: 2026-02-18 09:45
---

the aitask_create2 claude skill should not be user facing, it is used only by cluade to create task: set its metadata so that it is not user invocable and remove it from user documentation of available skills
