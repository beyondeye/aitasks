---
priority: medium
effort: medium
depends: []
issue_type: bug
status: Done
labels: [verifiedstats, aitask_pick]
assigned_to: dario-e@beyond-eye.com
implemented_with: claudecode/opus4_6
created_at: 2026-03-12 23:03
updated_at: 2026-03-12 23:40
completed_at: 2026-03-12 23:40
---

currently when aitask_pick is used only to decompose a task in child tasks, with no actual implementation the feedback procedure to vote model performance is not activated. it should
